package com.InfiniteStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfiniteStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
